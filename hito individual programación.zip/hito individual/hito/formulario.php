<!DOCTYPE html>
<html>
<head>
    <title>Formulario</title>
    <link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
    <h1>Formulario</h1>
    <form action="formulario.php" method="post" enctype="multipart/form-data">
        <label for="author_email">Email del cliente:</label>
        <input type="email" name="correo" required>

        <label for="title">Título:</label>
        <input type="text" name="titulo" required>

        <label for="content">Contenido:</label>
        <textarea name="contenido" required></textarea>

        <label for="publish_date">Fecha de publicación:</label>
        <input type="date" name="fechapubli" required>

        <label for="image">Imágen:</label>
        <input type="file" name="imagen"required>

        <input type="submit" value="Enviar">
        <?php
if(isset($_POST['correo']) && isset($_POST['titulo']) && isset($_POST['contenido'])){
    // $ID_FORMULARIO=$_POST['ID_FORMULARIO'];
    $email=$_POST['correo'];
    $titulo=$_POST['titulo'];
    $fechapublicacion=$_POST['fechapubli'];
    $imagen=$_POST['imagen'];
    $contenido=$_POST['contenido'];

    $conn = new PDO('mysql:host=localhost;dbname=test', 'root', '');
    $insertar= "INSERT INTO `hitoprogramacion` (`correo`, `titulo`, `fechapubli`, `contenido`,`imagen`) VALUES ('$email', '$titulo', '$fechapublicacion', '$contenido', '$imagen');";
    $registros = $conn->exec($insertar);
    header("location:autentificacion.php");
}
?>
    </form>
</body>
</html>
