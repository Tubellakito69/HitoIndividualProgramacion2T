<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Tipos de lenguajes de programación</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.3/umd/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="style.css">

  </head>
  <body>
    <div id="header-nav">
      <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">Tipos de lenguajes de programación</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="formulario.php">Formulario</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="datos.php">Todos los datos</a>
          </ul>
        </div>
      </nav>
    </div>
    </header>
    <main>
      <section id="1">
        <h2>Programación Orientada a Objetos POO</h2>
        <p>La programación orientada a objetos se centra en los objetos que los programadores quieren manipular en lugar de enfocarse en la lógica necesaria para manipularlos. Este enfoque de programación está hecho para programas que son grandes, dificiles y se actualizan diariamente. La organización de un programa orientado a objetos también hace que el método sea beneficioso para el desarrollo colaborativo, donde los proyectos se dividen en grupos.</p>
        <p>Algunos ejemplos de lenguajes de programación POO son Python y Java. Con POO se pueden hacer herencias,polimorfismos y encapsulaciones</p>
        <ul>
      </section>
      <section id="2">
        <h2>Lenguajes procedimentales</h2>
        <p>Los lenguajes de programación procedimentales son aquellos que se centran en la secuencia de instrucciones que un programa debe seguir para resolver un problema específico. Estos lenguajes se basan en la idea de que el programa es una secuencia de pasos o procedimientos que se ejecutan en un orden determinado.</p>
        <p>En un lenguaje procedimental, se definen los procedimientos que deben realizarse para llevar a cabo una tarea. Estos procedimientos pueden tomar argumentos y devolver valores, y pueden ser llamados desde otros procedimientos en el programa. Los procedimientos se definen utilizando estructuras de control de flujo, como bucles y condicionales.</p>
        <p>Algunos ejemplos de lenguajes de programación procedimentales incluyen C, Pascal, Fortran y Basic.</p>
      </section>
      <section id="3">
        <h2>Lenguaje orientado a eventos</h2>
        <p>Los programas en lenguajes orientados a eventos están compuestos por diferentes componentes que interactúan entre sí enviándose eventos. Estos componentes pueden ser objetos, funciones o módulos que se comunican a través de eventos que son enviados y recibidos. Cada componente se suscribe a los eventos que le interesan, y cuando ocurren, el componente responde en consecuencia.</p>
        <p>Uno de los beneficios clave de los lenguajes orientados a eventos es que permiten la programación asincrónica, lo que significa que las tareas pueden ejecutarse en segundo plano mientras se espera la respuesta de una tarea principal. Esto es especialmente útil para las aplicaciones web, donde se pueden enviar múltiples solicitudes al servidor al mismo tiempo sin esperar a que se complete una antes de comenzar la siguiente.</p>
      </section>
    </main>
  </body>
</html>